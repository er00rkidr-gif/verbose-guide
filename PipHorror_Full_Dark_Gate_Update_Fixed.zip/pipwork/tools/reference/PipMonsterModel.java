package com.pip.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.pip.PipEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Monster form: ~2 blocks tall, spindly arms to the knees, hanging jaw, huge glowing eyes (128x128 texture). */
public class PipMonsterModel extends EntityModel<PipEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation("pip", "pip_monster"), "main");
    private final ModelPart root, head, jaw, armL, armR, legL, legR, tail, earL, earR;

    public PipMonsterModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head"); jaw = head.getChild("jaw");
        armL = root.getChild("arm_l"); armR = root.getChild("arm_r");
        legL = root.getChild("leg_l"); legR = root.getChild("leg_r");
        tail = root.getChild("tail");
        earL = head.getChild("ear_l"); earR = head.getChild("ear_r");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        PartDefinition body = r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-3, -12, -2, 6, 12, 4), PartPose.offset(0, 10, 0));
        body.addOrReplaceChild("spine", CubeListBuilder.create().texOffs(72, 32).addBox(-1, -12, 2, 2, 10, 1), PartPose.ZERO);

        PartDefinition head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(24, 0).addBox(-4, -7, -4, 8, 7, 8), PartPose.offset(0, 8, 0));
        head.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(60, 0).addBox(-3.5f, 0, -4.5f, 7, 3, 7)
                .texOffs(90, 0).addBox(-3, -1, -4.6f, 6, 1, 1), PartPose.offset(0, -2, 0));
        head.addOrReplaceChild("teeth_u", CubeListBuilder.create().texOffs(90, 4).addBox(-3, -2, -4.2f, 6, 1, 1), PartPose.ZERO);
        head.addOrReplaceChild("ear_l", CubeListBuilder.create().texOffs(0, 20).addBox(-4, -12, -1, 2, 5, 1), PartPose.ZERO);
        head.addOrReplaceChild("ear_r", CubeListBuilder.create().texOffs(8, 20).addBox(2, -12, -1, 2, 5, 1), PartPose.ZERO);
        head.addOrReplaceChild("eye_l", CubeListBuilder.create().texOffs(16, 20).addBox(-3.5f, -5.5f, -4.02f, 3, 3, 0), PartPose.ZERO);
        head.addOrReplaceChild("eye_r", CubeListBuilder.create().texOffs(16, 26).addBox(0.5f, -5.5f, -4.02f, 3, 3, 0), PartPose.ZERO);

        r.addOrReplaceChild("arm_l", CubeListBuilder.create().texOffs(20, 32).addBox(-1, 0, -1, 2, 18, 2), PartPose.offset(4.5f, 10, 0));
        r.addOrReplaceChild("arm_r", CubeListBuilder.create().texOffs(30, 32).addBox(-1, 0, -1, 2, 18, 2), PartPose.offset(-4.5f, 10, 0));
        r.addOrReplaceChild("leg_l", CubeListBuilder.create().texOffs(0, 32).addBox(-1, 0, -1, 2, 14, 2), PartPose.offset(1.5f, 10, 0));
        r.addOrReplaceChild("leg_r", CubeListBuilder.create().texOffs(10, 32).addBox(-1, 0, -1, 2, 14, 2), PartPose.offset(-1.5f, 10, 0));
        r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(40, 32).addBox(-1, -1, 0, 2, 2, 12), PartPose.offset(0, 10, 2));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(PipEntity e, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        head.xRot = headPitch * ((float) Math.PI / 180F);
        head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        head.zRot = (float) Math.sin(age * 0.9f) * 0.02f;            // unsettling twitch
        jaw.xRot = 0.35f + Mth.sin(age * 0.15f) * 0.12f;             // jaw hangs open and works slowly
        earL.zRot = Mth.sin(age * 0.3f) * 0.08f;
        earR.zRot = -Mth.sin(age * 0.3f) * 0.08f;
        float s = Mth.cos(limbSwing * 0.6662f) * limbSwingAmount;
        armL.xRot = s * 0.8f + Mth.sin(age * 0.067f) * 0.05f;
        armR.xRot = -s * 0.8f - Mth.sin(age * 0.067f) * 0.05f;
        legL.xRot = -s * 1.1f; legR.xRot = s * 1.1f;
        tail.xRot = -0.4f;
        tail.yRot = Mth.sin(age * 0.05f) * 0.15f;
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, vc, light, overlay, r, g, b, a);
    }
}
