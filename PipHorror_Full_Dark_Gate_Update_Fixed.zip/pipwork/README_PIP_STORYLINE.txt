Pip Horror – updated storyline build source

Minecraft: Java Edition 1.20.1
Forge: 47.2.0
GeckoLib: Forge 1.20.1 / 4.4.9
Java toolchain: 17

Main changes in this update:
- Pip's Unknown Corpse is substantially easier to find in structure chests (10–18% chance per supported chest).
- Nights 1–3: normal Pip.
- Night 4: occasional ignoring behavior.
- Night 5 onward: fake Pip; head/body do not turn to follow the player, while pupils track the player.
- After 10 full nights: Pip changes to the monster form, using pip_monster.geo.json, pip_monster.png, and pip_monster.animation.json.
- After the owner wakes from sleep: Pip seeks nearby water, washes, and returns to its home position.
- Pip occasionally guards a nearby bed and prevents its use while guarding.
- Short and long talking animations have more varied mouth movement.

Build:
Run `gradle build` from this folder with Java 17 and a working internet connection for ForgeGradle dependencies.
The compiled mod jar will be in `build/libs/`.

Note: resource JSON validation passed. A full ForgeGradle compile was not possible in the editing environment (no Gradle installation / no network).
