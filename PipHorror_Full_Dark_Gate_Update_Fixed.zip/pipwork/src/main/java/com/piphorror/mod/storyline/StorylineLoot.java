package com.piphorror.mod.storyline;

import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.init.ModItems;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

/** Slips an Unknown Corpse into some vanilla chests so the story can start with "we find Pip in a chest". */
@Mod.EventBusSubscriber(modid = PipHorrorMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class StorylineLoot {
    /** Chest loot table path -> chance (0..1) that the chest contains Pip's Unknown Corpse.
     * Raised substantially so starting the storyline does not require dozens of explored structures.
     */
    private static final Map<String, Float> CHESTS = Map.ofEntries(
        Map.entry("chests/simple_dungeon", 0.18F),
        Map.entry("chests/abandoned_mineshaft", 0.16F),
        Map.entry("chests/shipwreck_treasure", 0.17F),
        Map.entry("chests/shipwreck_supply", 0.10F),
        Map.entry("chests/buried_treasure", 0.18F),
        Map.entry("chests/underwater_ruin_big", 0.12F),
        Map.entry("chests/desert_pyramid", 0.15F),
        Map.entry("chests/jungle_temple", 0.15F),
        Map.entry("chests/stronghold_corridor", 0.14F),
        Map.entry("chests/woodland_mansion", 0.16F),
        Map.entry("chests/ancient_city", 0.18F),
        Map.entry("chests/igloo_chest", 0.10F),
        Map.entry("chests/pillager_outpost", 0.14F)
    );

    @SubscribeEvent
    public static void onLootTableLoad(LootTableLoadEvent event) {
        ResourceLocation name = event.getName();
        if (!"minecraft".equals(name.getNamespace())) {
            return;
        }
        Float chance = CHESTS.get(name.getPath());
        if (chance == null) {
            return;
        }
        event.getTable().addPool(LootPool.lootPool()
            .name("piphorror_unknown_corpse")
            .setRolls(ConstantValue.exactly(1.0F))
            .when(LootItemRandomChanceCondition.randomChance(chance))
            .add(LootItem.lootTableItem(ModItems.UNKNOWN_CORPSE.get()))
            .build());
    }
}
