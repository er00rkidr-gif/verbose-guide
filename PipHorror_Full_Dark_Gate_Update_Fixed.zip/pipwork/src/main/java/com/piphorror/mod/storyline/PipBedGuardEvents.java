package com.piphorror.mod.storyline;

import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.entity.PipChatListener;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Occasionally Pip camps beside a nearby bed and stubbornly refuses to move away from it. */
@Mod.EventBusSubscriber(modid = PipHorrorMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PipBedGuardEvents {
    private PipBedGuardEvents() {}

    @SubscribeEvent
    public static void onBedUse(PlayerInteractEvent.RightClickBlock event) {
        if (!(event.getEntity().level() instanceof ServerLevel level)) return;
        BlockPos pos = event.getPos();
        BlockState state = level.getBlockState(pos);
        if (!state.is(BlockTags.BEDS)) return;

        AABB area = new AABB(pos).inflate(2.6D);
        for (PipChatListener pip : level.getEntitiesOfClass(PipChatListener.class, area)) {
            if (pip.isGuardingBed(pos)) {
                event.setCanceled(true);
                event.setCancellationResult(InteractionResult.FAIL);
                event.getEntity().displayClientMessage(
                    Component.literal("§7Pip is standing far too close to the bed. It won't let you use it."), true);
                return;
            }
        }
    }
}
